import numpy as np
import math


def factorial(num):
    fact = 1
    counter = num
    try:
        while counter > 0:
            fact = fact*counter
            counter -= 1
        fact=str(fact)
        return fact
    except Exception:
        pass


def ten_pow(mod):

    try:
        mod=10**mod
        return mod
    except Exception:
        pass
def plus_minus1(mod):
    try:
        mod = mod*(-1)
        return mod
    except Exception:
        pass

def log1(mod):
    #ln
    try:
        mod = np.log(mod)
        return mod
    except Exception:
        pass

def log2(mod):

    try:
        mod = math.log(mod,10)
        return mod
    except Exception:
        pass

def exp1(mod):

    try:
        mod = math.exp(mod)
        return mod
    except Exception:
        pass

