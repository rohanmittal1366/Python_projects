
from tkinter import *
import numpy as np
import math
import calculator as clc
import parser

i=0

def factorial():
    num = display.get()
    if num.isdigit():
        num = float(num)
    num1=clc.factorial(num)
    try:
        clear()
        display.insert(0, num1)
    except Exception:
        clear()
        display.insert(0, "Error")


def mod2():
    whole_string = display.get()
    mod = int(whole_string)
    try:
        if mod < 0:
            mod = mod * -1
        clear()
        display.insert(0,mod)
    except Exception:
        clear()
        display.insert(0, "Error")

def ten_pow():
    num = display.get()
    if num.isdigit():
        num = float(num)
    mod = clc.ten_pow(num)
    try:
        clear()
        display.insert(0,mod)
    except Exception:
        clear()
        display.insert(0, "Error")

def plus_minus1():
    num = display.get()
    if num.isdigit():
        num = float(num)
    mod = clc.plus_minus(num)
    try:
        clear()
        display.insert(0,mod)
    except Exception:
        clear()
        display.insert(0, "Error")

def log1():
    #ln
    num = display.get()
    if num.isdigit():
        num = float(num)
    mod = clc.log1(num)
    try:
        clear()
        display.insert(0,mod)
    except Exception:
        clear()
        display.insert(0, "Error")

def log2():
    #log base 10
    num = display.get()
    if num.isdigit():
        num = float(num)
    mod = clc.log2(num)
    try:
        clear()
        display.insert(0,mod)
    except Exception:
        clear()
        display.insert(0, "Error")

def exp1():
    num = display.get()
    if num.isdigit():
        num = float(num)
    mod = clc.exp1(num)
    try:
        clear()
        display.insert(0,mod)
    except Exception:
        clear()
        display.insert(0, "Error")

def clear():
    display.delete(0, END)

def press(num):
    global i
    display.insert(i, num)
    i += 1

def get_operation(operator):
    global i
    length = len(operator)
    display.insert(i, operator)
    i += length

def undo():
    whole_string = display.get()
    if len(whole_string):
        new_string = whole_string[:-1]
        print(new_string)
        clear()
        display.insert(0, new_string)
    else:
        clear()
        display.insert(0, "Error, press AC")

def calculate():
    whole_string = display.get()
    try:
        formulae = parser.expr(whole_string).compile()
        result = eval(formulae)
        clear()
        display.insert(0, result)

    except Exception:
        clear()
        display.insert(0, "Error!")


# Driver code
if __name__ == "__main__":
    gui = Tk()
    gui.configure(background="light grey")
    gui.title("Scientific Calculator")
    gui.geometry("430x260")

    display = Entry(gui, font=("Calibri", 13))
    display.grid(row=0, columnspan=6, sticky=W + E)

    button1 = Button(gui, text=' 1 ', fg='black', bg='white',
                    command=lambda: press(1), height=1, width=7, font=("Calibri") )
    button1.grid(row=11, column=1)

    button2 = Button(gui, text=' 2 ', fg='black', bg='white',
                    command=lambda: press(2), height=1, width=7, font=("Calibri") )
    button2.grid(row=11, column=2)

    button3 = Button(gui, text=' 3 ', fg='black', bg='white',
                    command=lambda: press(3), height=1, width=7, font=("Calibri") )
    button3.grid(row=11, column=3)

    button4 = Button(gui, text=' 4 ', fg='black', bg='white',
                    command=lambda: press(4), height=1, width=7, font=("Calibri") )
    button4.grid(row=10, column=1)

    button5 = Button(gui, text=' 5 ', fg='black', bg='white',
                    command=lambda: press(5), height=1, width=7, font=("Calibri") )
    button5.grid(row=10, column=2)

    button6 = Button(gui, text=' 6 ', fg='black', bg='white',
                    command=lambda: press(6), height=1, width=7, font=("Calibri") )
    button6.grid(row=10, column=3)

    button7 = Button(gui, text=' 7 ', fg='black', bg='white',
                    command=lambda: press(7), height=1, width=7, font=("Calibri") )
    button7.grid(row=9, column=1)

    button8 = Button(gui, text=' 8 ', fg='black', bg='white',
                    command=lambda: press(8), height=1, width=7, font=("Calibri") )
    button8.grid(row=9, column=2)

    button9 = Button(gui, text=' 9 ', fg='black', bg='white',
                    command=lambda: press(9), height=1, width=7, font=("Calibri") )
    button9.grid(row=9, column=3)

    button0 = Button(gui, text=' 0 ', fg='black', bg='white',
                    command=lambda: press(0), height=1, width=7, font=("Calibri"))
    button0.grid(row=12, column=2)

    undo_button = Button(gui, text="<-", command=undo, font=("Calibri", 12),height=1, width=4, foreground="red")
    undo_button.grid(row=6, column=4)

    plus = Button(gui, text=' + ', fg='black', bg='light grey',
                command=lambda: get_operation("+"), height=1, width=4, font=("Calibri") )
    plus.grid(row=11, column=4)

    minus = Button(gui, text=' - ', fg='black', bg='light grey',
                command=lambda: get_operation("-"), height=1, width=4, font=("Calibri") )
    minus.grid(row=10, column=4)

    multiply = Button(gui, text=' * ', fg='black', bg='light grey',
                    command=lambda: get_operation("*"), height=1, width=4, font=("Calibri")  )
    multiply.grid(row=9, column=4)

    divide = Button(gui, text=' / ', fg='black', bg='light grey',
                    command=lambda: get_operation("/"), height=1, width=4, font=("Calibri")  )
    divide.grid(row=8, column=4)

    result = Button(gui, text="=", command=calculate, font=("Calibri"),height=1, width=4, foreground="red")
    result.grid(row=12, column=4)

    cls = Button(gui, text="AC", command=clear, font=("Calibri"), height=1, width=7, foreground="red")
    cls.grid(row=6, column=3)

    sqrt = Button(gui, text="x\u00b2", fg='black', bg='light grey',
                   command=lambda: get_operation("**2"), height=1, width=4, font=("Calibri")  )
    sqrt.grid(row=7, column='0')

    cube = Button(gui, text='x\u00b3', fg='black', bg='light grey',
                   command=lambda: get_operation("**3"), height=1, width=4, font=("Calibri")  )
    cube.grid(row=8, column='0')

    pow = Button(gui, text='x\u207f', fg='black', bg='light grey',
                   command=lambda: get_operation("**"), height=1, width=4, font=("Calibri")  )
    pow.grid(row=9, column='0')

    Decimal= Button(gui, text='.', fg='black', bg='light grey',
                    command=lambda: press('.'), height=1, width=7, font=("Calibri")  )
    Decimal.grid(row=12, column=3)

    log = Button(gui, text='log', fg='black', bg='light grey',
                 command=log2, height=1, width=4, font=("Calibri")  )
    log.grid(row=11, column='0')

    ln = Button(gui, text='ln', fg='black', bg='light grey',
                 command=log1, height=1, width=4, font=("Calibri")  )
    ln.grid(row=12, column='0')

    pi = Button(gui, text='\u213c', fg='black', bg='light grey',
                command=lambda: get_operation("*3.14"), height=1, width=7, font=("Calibri")  )
    pi.grid(row=6, column='1')

    e = Button(gui, text='e', fg='black', bg='light grey',
                command=lambda: get_operation("*2.718"), height=1, width=7, font=("Calibri")  )
    e.grid(row=6, column='2')

    inv = Button(gui, text='1/x', fg='black', bg='light grey',
                command=lambda: get_operation("**(-1)"), height=1, width=7, font=("Calibri")  )
    inv.grid(row=7, column='1')

    brac = Button(gui, text='(', fg='black', bg='light grey',
                 command=lambda: get_operation("("), height=1, width=7, font=("Calibri")  )
    brac.grid(row=8, column='1')

    brac1 = Button(gui, text=')', fg='black', bg='light grey',
                  command=lambda: get_operation(")"), height=1, width=7, font=("Calibri")  )
    brac1.grid(row=8, column='2')

    exp = Button(gui, text='exp', fg='black', bg='light grey',
                  command=exp1, height=1, width=7, font=("Calibri")  )
    exp.grid(row=7, column='3')

    fact = Button(gui, text='n!', fg='black', bg='light grey',
                 command=factorial, height=1, width=7, font=("Calibri")  )
    fact.grid(row=8, column='3')

    mod = Button(gui, text='|x|', fg='black', bg='light grey',
                 command=mod2, height=1, width=7, font=("Calibri")  )
    mod.grid(row=7, column='2')

    ten_pow2 = Button(gui, text='10\u207f', fg='black', bg='light grey',
                 command=ten_pow, height=1, width=4, font=("Calibri")  )
    ten_pow2.grid(row=10, column='0')

    plus_minus = Button(gui, text='\u207a/\u208b', fg='black', bg='light grey',
                  command=plus_minus1, height=1, width=7, font=("Calibri")  )
    plus_minus.grid(row=12, column='1')

    modulo = Button(gui, text='mod', fg='black', bg='light grey',
                  command=lambda: get_operation("%"), height=1, width=4, font=("Calibri")  )
    modulo.grid(row=7, column='4')

    gui.mainloop()
